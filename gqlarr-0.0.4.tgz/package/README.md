# GQLARR

GQLARR (GraphQL Almighty Root Resolver, pronounced "G-Clar") is a 
[GraphQL Codegen](https://the-guild.dev/graphql/codegen) plugin